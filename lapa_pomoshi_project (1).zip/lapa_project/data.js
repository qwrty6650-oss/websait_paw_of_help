const allPets=[
{id:1,name:'Бим',species:'Собака',gender:'Мальчик',age:2,size:'Средний',breed:'Метис',badge:'urgent',badgeText:'Срочно',img:'https://images.unsplash.com/photo-1543466835-00a7907e9de1?auto=format&fit=crop&w=700&q=80',tags:['Активный','Дружелюбный'],shortDesc:'Добрый и активный пёс, который любит прогулки и людей.'},
{id:2,name:'Люся',species:'Собака',gender:'Девочка',age:1,size:'Маленький',breed:'Метис',badge:'new',badgeText:'Новенькая',img:'https://images.unsplash.com/photo-1517849845537-4d257902454a?auto=format&fit=crop&w=700&q=80',tags:['Ласковая','Спокойная'],shortDesc:'Нежная собачка, которая быстро привязывается к человеку.'},
{id:3,name:'Мурка',species:'Кошка',gender:'Девочка',age:3,size:'Маленький',breed:'Домашняя',badge:null,img:'https://images.unsplash.com/photo-1533738363-b7f9aef128ce?auto=format&fit=crop&w=700&q=80',tags:['Ласковая','Игривая'],shortDesc:'Любопытная кошка с мягким характером.'},
{id:4,name:'Рекс',species:'Собака',gender:'Мальчик',age:5,size:'Большой',breed:'Метис',badge:'adult',badgeText:'Взрослый',img:'https://images.unsplash.com/photo-1552053831-71594a27632d?auto=format&fit=crop&w=700&q=80',tags:['Умный','Верный'],shortDesc:'Спокойный взрослый пёс, которому нужен надёжный хозяин.'},
{id:5,name:'Багира',species:'Кошка',gender:'Девочка',age:2,size:'Средний',breed:'Домашняя',badge:null,img:'https://images.unsplash.com/photo-1573865526739-10659fec78a5?auto=format&fit=crop&w=700&q=80',tags:['Грациозная','Независимая'],shortDesc:'Самостоятельная и красивая кошка.'},
{id:6,name:'Тимка',species:'Собака',gender:'Мальчик',age:.5,size:'Маленький',breed:'Метис',badge:'urgent',badgeText:'Срочно',img:'https://images.unsplash.com/photo-1587300003388-59208cc962cb?auto=format&fit=crop&w=700&q=80',tags:['Щенок','Весёлый'],shortDesc:'Маленький щенок, полный энергии.'},
{id:7,name:'Сима',species:'Кошка',gender:'Девочка',age:4,size:'Маленький',breed:'Домашняя',badge:null,img:'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?auto=format&fit=crop&w=700&q=80',tags:['Спокойная','Нежная'],shortDesc:'Тихая кошечка для уютного дома.'},
{id:8,name:'Барс',species:'Кот',gender:'Мальчик',age:6,size:'Средний',breed:'Домашний',badge:'adult',badgeText:'Взрослый',img:'https://images.unsplash.com/photo-1518791841217-8f162f1e1131?auto=format&fit=crop&w=700&q=80',tags:['Самостоятельный','Умный'],shortDesc:'Уверенный в себе кот с характером.'}
];
function getFavorites(){try{return JSON.parse(localStorage.getItem('lapa_favorites')||'[]')}catch{return[]}}
function setFavorites(v){localStorage.setItem('lapa_favorites',JSON.stringify(v))}
function toggleFavorite(id){const a=getFavorites();const i=a.indexOf(id);i>=0?a.splice(i,1):a.push(id);setFavorites(a);return i<0}
function authorized(){return localStorage.getItem('lapa_authorized')==='true'}
function getUser(){try{return JSON.parse(localStorage.getItem('lapa_user')||'null')}catch{return null}}
function ageText(age){if(age<1)return 'мес.';const n=Math.floor(age);return n===1?'год':n>=2&&n<=4?'года':'лет'}
function showToast(msg){const t=document.getElementById('toast');if(!t)return;t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2200)}
